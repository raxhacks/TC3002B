# Ejecutar tarea

- `cd ~/Tarea1_A01284709`
- `go run .`